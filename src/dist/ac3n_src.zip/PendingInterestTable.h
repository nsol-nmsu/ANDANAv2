#ifndef PENDINGINTERESTTABLE_H_
#define PENDINGINTERESTTABLE_H_

typedef struct 
{
	// TOOD
} PendingInterestTable;

#endif /* PENDINGINTERESTTABLE_H_ */
